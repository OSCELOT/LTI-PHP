<?php
/*
  Plugin Name: ceLTIc LTI Library
  Plugin URI: https://github.com/celtic-project/LTI-PHP
  Description: This plugin to installs the ceLTIc LTI class library for use by other plugins.
  Version: 5.3.0
  Network: true
  Requires at least: 5.9
  Requires PHP: 8.1
  Author: Stephen P Vickers
  Author URI: http://www.celtic-project.org/
  License: GPLv3
 */

/*
 *  celtic-lti - WordPress plugin to install the ceLTIc LTI class library
 *  Copyright (C) 2025  Stephen P Vickers
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *  Contact: stephen@spvsoftwareproducts.com
 */

use ceLTIc\LTI\Util;
use ceLTIc\LTI\Enum\LogLevel;
use ceLTIc\LTI\Enum\IdScope;

// Prevent loading this file directly
defined('ABSPATH') || exit;

// include the LTI library classes
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php');

/* -------------------------------------------------------------------
 * Get capability required to access admin options
  ------------------------------------------------------------------ */

function celtic_lti_get_admin_menu_page_capability()
{
    if (is_multisite()) {
        $capability = 'manage_network_options';
    } else {
        $capability = 'manage_options';
    }

    return $capability;
}

/* -------------------------------------------------------------------
 * Add settings page option
  ------------------------------------------------------------------ */

function celtic_lti_register_manage_settings_page()
{
    // If plugin not actve simply return
    if ((is_multisite() && !is_plugin_active_for_network('celtic-lti/celtic-lti.php')) ||
        (!is_multisite() && !is_plugin_active('celtic-lti/celtic-lti.php'))) {
        return;
    }

    $capability = celtic_lti_get_admin_menu_page_capability();
    add_submenu_page('celtic_lti', __('Settings', 'celtic-lti'), __('Settings', 'celtic-lti'), $capability, 'celtic_lti_options',
        'celtic_lti_options_page');
}

if (is_multisite()) {
    add_action('network_admin_menu', 'celtic_lti_register_manage_settings_page');
} else {
    add_action('admin_menu', 'celtic_lti_register_manage_settings_page');
}

/* -------------------------------------------------------------------
 * Add a settings link to the plugins page
  ------------------------------------------------------------------ */

function celtic_lti_plugin_settings_link($links)
{
    if (!isset($links['activate'])) {
        $url = add_query_arg(array('page' => 'celtic_lti_options'), 'admin.php');
        array_unshift($links,
            sprintf('<a href="%1$s" title="%2$s">%3$s</a>', esc_url($url), esc_html__('Change plugin settings', 'celtic-lti'),
                esc_html__('Settings', 'celtic-lti')));
    }

    return $links;
}

$prefix = '';
if (is_multisite()) {
    $prefix = 'network_admin_';
}
add_filter("{$prefix}plugin_action_links_celtic-lti/celtic-lti.php", 'celtic_lti_plugin_settings_link');

/* -------------------------------------------------------------------
 * Get the current option settings
  ------------------------------------------------------------------ */

function celtic_lti_get_options()
{
    global $celtic_lti_options;

    if (empty($celtic_lti_options)) {
        $default_options = array('loglevel' => strval(LogLevel::None->value), 'encryptionkey' => '');
        if (is_multisite()) {
            $options = get_site_option('celtic_lti_options', array());
        } else {
            $options = get_option('celtic_lti_options', array());
        }
        if (!is_array($options)) {
            $options = array();
        }
        $celtic_lti_options = array_merge($default_options, $options);
    }

    return $celtic_lti_options;
}

/* -------------------------------------------------------------------
 * Initialisation when WordPress is initialised
  ------------------------------------------------------------------ */

function celtic_lti_init()
{
    // Set logging level
    $options = celtic_lti_get_options();
    Util::$logLevel = LogLevel::tryFrom(intval($options['loglevel']));

    // Set encryption key
    $encryptionKey = base64_decode($options['encryptionkey'], true);
    if (!empty($encryptionKey)) {
        Util::$encryptionKey = $encryptionKey;
    }
}

add_action('init', 'celtic_lti_init');

/* -------------------------------------------------------------------
 * Define general section for settings page
  ------------------------------------------------------------------ */

function celtic_lti_options_general_section_info()
{
    echo('<h2>' . __('General', 'celtic-lti') . "</h2>\n");
}

/* -------------------------------------------------------------------
 * Define log level field for settings page
  ------------------------------------------------------------------ */

function celtic_lti_loglevel_callback()
{
    $name = 'loglevel';
    $options = celtic_lti_get_options();
    $current = $options[$name];
    printf('<select name="celtic_lti_options[%s]" id="%s">', esc_attr($name), esc_attr($name));
    echo "\n";
    $none_loglevel = LogLevel::None;  // Avoid parse error in PHP < 8.1
    $error_loglevel = LogLevel::Error;
    $info_loglevel = LogLevel::Info;
    $debug_loglevel = LogLevel::Debug;
    $loglevels = array(__('No logging', 'lti-tool') => strval($none_loglevel->value), __('Log errors only', 'lti-tool') => strval($error_loglevel->value),
        __('Log error and information messages', 'lti-tool') => strval($info_loglevel->value), __('Log all messages', 'lti-tool') => strval($debug_loglevel->value));
    foreach ($loglevels as $key => $value) {
        $selected = ($value === $current) ? ' selected' : '';
        printf('  <option value="%s"%s>%s</option>', esc_attr($value), esc_attr($selected), esc_html($key));
        echo "\n";
    }
    echo ("</select>\n");
}

/* -------------------------------------------------------------------
 * Define encryption key field for settings page
  ------------------------------------------------------------------ */

function celtic_lti_encryptionkey_callback()
{
    $options = celtic_lti_get_options();
    printf(
        '<input type="text" name="celtic_lti_options[encryptionkey]" id="encryptionkey" size="50" value="%s"> <label for="encryptionkey">' . __('Enter a base64-formatted string to enable encryption of shared secrets',
            'lti-tool') . '</label>', esc_attr($options['encryptionkey'])
    );
    echo "\n";
}

/* -------------------------------------------------------------------
 * Define settings page
  ------------------------------------------------------------------ */

function celtic_lti_options_init()
{
    register_setting('celtic_lti_options_settings_group', 'celtic_lti_options');
    add_settings_section(
        'celtic_lti_options_general_section', '', 'celtic_lti_options_general_section_info', 'celtic_lti_options_admin'
    );

    add_settings_field(
        'loglevel', __('Default logging level', 'celtic-lti'), 'celtic_lti_loglevel_callback', 'celtic_lti_options_admin',
        'celtic_lti_options_general_section'
    );

    add_settings_field(
        'encryptionkey', __('Encryption key', 'celtic-lti'), 'celtic_lti_encryptionkey_callback', 'celtic_lti_options_admin',
        'celtic_lti_options_general_section'
    );

    do_action('celtic_lti_init_options');
}

add_action('admin_init', 'celtic_lti_options_init');

/* -------------------------------------------------------------------
 * Display settings page
  ------------------------------------------------------------------ */

function celtic_lti_options_page()
{
    ?>
    <div class="wrap">
      <h1 class="wp-heading-inline"><?php _e('Settings', 'celtic-lti'); ?></h1>
      <?php settings_errors(); ?>

      <form method="post" action="<?php echo esc_url(get_option('siteurl')) . '/?celtic-lti&saveoptions'; ?>">
        <?php
        settings_fields('celtic_lti_options_settings_group');
        do_settings_sections('celtic_lti_options_admin');
        submit_button();
        ?>
      </form>
    </div>
    <?php
}

/* -------------------------------------------------------------------
 * This is called by Wordpress when it parses a request. Therefore
 * need to be careful when the request isn't for this plugin.
 *
 * Parameters
 *  $wp - WordPress environment class
  ------------------------------------------------------------------- */

function celtic_lti_parse_request($wp)
{
    if (isset($_GET['celtic-lti'])) {
        if (isset($_GET['saveoptions'])) {
            require_once(ABSPATH . 'wp-admin/includes/template.php');

            if (!current_user_can(celtic_lti_get_admin_menu_page_capability())) {
                wp_die(
                    '<h1>' . __('You need a higher level of permission.', 'celtic-lti') . '</h1>' .
                    '<p>' . __('Sorry, you are not allowed to access admin options for this site.', 'celtic-lti') . '</p>', 403
                );
            }

            $nonce = sanitize_text_field($_REQUEST['_wpnonce']);
            if (!wp_verify_nonce($nonce, 'celtic_lti_options_settings_group-options')) {
                add_settings_error('general', 'settings_updated',
                    __('Unable to submit this form, please refresh and try again.', 'celtic-lti'));
            } else {
                $rawoptions = stripslashes_deep($_POST['celtic_lti_options']);
                $options = array();
                foreach ($rawoptions as $option => $value) {
                    $option = sanitize_text_field($option);
                    switch ($option) {
                        case 'encryptionkey':
                            $value = sanitize_text_field($value);
                            if (!empty($value)) {
                                $decoded = base64_decode($value, true);
                                if ($decoded === false) {
                                    add_settings_error('general', 'settings_updated',
                                        __('Encryption key is not a valid base64-encoded string.'), 'error');
                                } elseif (strlen($decoded) < 32) {
                                    add_settings_error('general', 'settings_updated',
                                        __('An encryption key length of at least 32 bytes is recommended.'), 'warning');
                                }
                            }
                            break;
                    }
                    $options[$option] = $value;
                }
                error_log('options: ' . var_export($options, true));
                if (is_multisite()) {
                    update_site_option('celtic_lti_options', $options);
                } else {
                    update_option('celtic_lti_options', $options);
                }
                add_settings_error('general', 'settings_updated', __('Settings saved.'), 'success');
            }
            set_transient('settings_errors', get_settings_errors(), 30);

            if (is_multisite()) {
                $path = add_query_arg(array('page' => 'celtic_lti_options', 'settings-updated' => 'true'),
                    network_admin_url('admin.php'));
            } else {
                $path = add_query_arg(array('page' => 'celtic_lti_options', 'settings-updated' => 'true'), admin_url('admin.php'));
            }

            wp_redirect($path);
            exit;
        }
    }
}

add_action('parse_request', 'celtic_lti_parse_request');
