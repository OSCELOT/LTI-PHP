<?php
/*
 *  celtic-lti - WordPress module to install the ceLTIc LTI class library
 *  Copyright (C) 2025  Stephen P Vickers
 *
 *  Author: stephen@spvsoftwareproducts.com
 */

// Dummy page
?>
