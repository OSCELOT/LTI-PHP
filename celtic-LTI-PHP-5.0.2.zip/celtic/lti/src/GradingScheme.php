<?php
declare(strict_types=1);

namespace ceLTIc\LTI;

/**
 * Class to represent a line-item grading scheme
 *
 * @author  Stephen P Vickers <stephen@spvsoftwareproducts.com>
 * @copyright  SPV Software Products
 * @license  http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3
 */
class GradingScheme
{

    /**
     * Label value.
     *
     * @var string $label
     */
    public string $label;

    /**
     * Description value.
     *
     * @var string|null $description
     */
    public ?string $description = null;

    /**
     * Items comprising possible outcome values.
     *
     * @var array $items
     */
    public array $items;

    /**
     * Class constructor.
     *
     * @param string $label             Label
     * @param string|null $description  Description
     * @param array $items              Grading scheme items
     */
    public function __construct(string $label, ?string $description, array $items)
    {
        $this->label = $label;
        $this->description = $description;
        $this->items = $items;
    }

    /**
     * Generate the JSON object representation of the grading scheme.
     *
     * @return object
     */
    public function toJsonObject(): object
    {
        $gradingScheme = new \stdClass();
        $gradingScheme->label = $this->label;
        if (!empty($this->description)) {
            $gradingScheme->description = $this->description;
        }
        $gradingScheme->items = $this->items;

        return $gradingScheme;
    }

    /**
     * Generate a GradingScheme object from its JSON representation.
     *
     * @param object $gradingScheme  A JSON object representing a line-item grading scheme
     *
     * @return GradingScheme|null  The GradingScheme object
     */
    public static function fromJsonObject(object $gradingScheme): ?GradingScheme
    {
        $obj = null;
        if (is_object($gradingScheme)) {
            $label = null;
            $description = null;
            $items = null;
            if (!empty($gradingScheme->label)) {
                $label = $gradingScheme->label;
            }
            if (!empty($gradingScheme->description)) {
                $description = $gradingScheme->description;
            }
            if (!empty($gradingScheme->items)) {
                $items = $gradingScheme->items;
            }
            if (!empty($label) && !empty($items)) {
                $obj = new GradingScheme($label, $description, $items);
            }
        }

        return $obj;
    }

}
